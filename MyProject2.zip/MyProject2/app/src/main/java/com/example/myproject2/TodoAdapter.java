package com.example.myproject2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class TodoAdapter extends RecyclerView.Adapter<TodoAdapter.ViewHolder> { //alt+enter > 새로운 대안 도구

    private ArrayList<Todo> mData = null; //Todo라는 객체를 가진 ArrayList 생성

    // item View 를 저장하는 뷰홀더 클래스
    public class ViewHolder extends RecyclerView.ViewHolder {

        protected TextView textview_todo_item;
        protected ImageButton deleteBt;

        public ViewHolder(View itemView) {
            super(itemView);

            this.textview_todo_item = itemView.findViewById(R.id.textview_todo_item);
            this.deleteBt = itemView.findViewById(R.id.button_todo_item);


            //ArrayList 삭제 버튼
            deleteBt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();

                    if(position != RecyclerView.NO_POSITION){
                        mData.remove(position);
                        notifyDataSetChanged(); //어뎁터에게 데이터 셋이 변경되었음을 알린다.
                    }
                }
            });
        }
    }

    // 생성자에서 데이터 리스트 객체를 전달받음
    TodoAdapter(ArrayList<Todo> list){
        mData = list;
    }

    @Override
    public TodoAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext() ;
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) ;

        View view = inflater.inflate(R.layout.recyclerview_item, parent, false) ;
        TodoAdapter.ViewHolder vh = new TodoAdapter.ViewHolder(view) ;

        return vh ;
    }

    @Override
    public void onBindViewHolder(TodoAdapter.ViewHolder holder, int position) {
        holder.textview_todo_item.setText(mData.get(position).getTodoName()); //직접적으로 binding 해주는 것
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }
}
